<?php
/**
 * Plugin Name: Elementor Addon
 * Description: Simple hello world widgets for Elementor.
 * Version:     1.0.0
 * Author:      Elementor Developer
 * Author URI:  https://developers.elementor.com/
 * Text Domain: elementor-addon
 *
 * Requires Plugins: elementor
 * Elementor tested up to: 3.24.0
 * Elementor Pro tested up to: 3.24.0
 */

function elementor_addons( $widgets_manager ) {
    // Include widget files
    require_once( __DIR__ . '/widgets/text-widget.php' );
    require_once( __DIR__ . '/widgets/text-widget-pro.php' );

    // Register widgets
    $widgets_manager->register( new \image_box() );
    $widgets_manager->register( new \Texts_Widget_Pro() );
}
add_action( 'elementor/widgets/register', 'elementor_addons' );
