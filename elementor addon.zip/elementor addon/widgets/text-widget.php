<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
class image_box extends \Elementor\Widget_Base {
    public function get_name(): string {
        return 'image_box';
    }

    public function get_title(): string {
        return esc_html__( 'image_box', 'elementor-addon' );
    }

    public function get_icon(): string {
        return 'eicon-image-box';
    }

    public function get_categories(): array {
        return [ 'basic' ];
    }

    public function get_keywords(): array {
        return [ 'image', 'box' ];
    }

    //content tabs start
    protected function register_controls(): void {

        $this->start_controls_section(
            'image_Box',
            [
                'label' => esc_html__( 'Image_Box', 'elementor-addon' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => esc_html__( 'Choose Image', 'elementor-addon' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),

                ],
            ]
        );

        $this->add_control(
            'name',
            [
                'label' => esc_html__( 'Name', 'elementor-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '', 'elementor-addon' ),
                'placeholder' => esc_html__( 'Type your title here', 'elementor-addon' ),
            ]
        );

         $this->add_control(
            'designation',
            [
                'label' => esc_html__( 'Designation', 'elementor-addon' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( '', 'elementor-addon' ),
                'placeholder' => esc_html__( 'Type your designation here', 'elementor-addon' ),
            ]
        );

         $this->end_controls_section();



        $this->start_controls_section(
            'Name_style',
            [
                'label' => esc_html__( 'Name', 'elementor-addon' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'text_align',
            [
                'label' => esc_html__( 'Alignment', 'elementor-addon' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'elementor-addon' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'elementor-addon' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'elementor-addon' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .name' => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .designation' => 'text-align: {{VALUE}};',
                ],
                'separator' => 'after',
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .name',
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label' => esc_html__( 'Text Color', 'elementor-addon' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .name' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .name:hover' => 'color: {{VALUE}}',
                
                ],
            ]
        );

        $this->add_control(
    'hover_text_color',
    [
        'label' => esc_html__( 'Text Hover Color', 'elementor-addon' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .name:hover' => 'color: {{VALUE}}',
        ],
        'separator' => 'after',

    ]
);


         $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'selector' => '{{WRAPPER}} .designation',
            ]
        );

        $this->add_control(
            'designation_color',
            [
                'label' => esc_html__( 'Designation Color', 'elementor-addon' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .designation' => 'color: {{VALUE}}',
                
                ],
                
            ]
        );
        $this->add_control(
    'designation_hover_color',
    [
        'label' => esc_html__( 'Designation Hover Color', 'elementor-addon' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .designation:hover' => 'color: {{VALUE}}',
        ],
    ]
);

         $this->end_controls_section();


}


        protected function render(): void {
        $settings = $this->get_settings_for_display();
        if ( empty( $settings['image']['url'] ) ) {
            return;
        }
            echo '<img src="' . $settings['image']['url'] . '">';
            ?>
            <h2 class="name">
            <?php echo $settings['name']; ?>
        </h2>
        <p class="designation">
            <?php echo $settings['designation']; ?>
        </p>
        <?php
        }

    


}